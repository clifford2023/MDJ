import subprocess
import os, sys

prj_name = 'P1'
app_name = 'app1'

res_prj = subprocess.run([ sys.executable, '-m', 'django','startproject', prj_name ], check=True, stdout=subprocess.PIPE)

# 进入子目录
os.chdir( prj_name )

res_app = subprocess.run([sys.executable, 'manage.py', 'startapp', '{0}'.format(app_name)], check=True )

print('...生成应用："{0}" '.format(app_name))